﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            SoulMaster soulmaster = new SoulMaster("gosho", 70);

            System.Console.WriteLine(soulmaster);
        }
    }
}