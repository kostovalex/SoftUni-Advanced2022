﻿namespace EncapsulationExercise
{
    public static class ExceptionMessages
    {
        public const string CANNOT_BE_NEGATIVE = "{0} cannot be zero or negative.";
    }
}
