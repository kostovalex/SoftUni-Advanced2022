﻿
namespace Telephony.Core.Interefaces
{
    public interface IEngine
    {
        void Run();
    }
}
