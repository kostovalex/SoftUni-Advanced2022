﻿
namespace BorderControl.IO.Interfaces
{
    public interface IReader
    {
        string Read();
    }
}
