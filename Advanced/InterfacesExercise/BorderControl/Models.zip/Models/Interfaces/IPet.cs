﻿
namespace BorderControl.Models.Interfaces
{
    internal interface IPet : IBirthable
    {
        string Name { get; }
    }
}
