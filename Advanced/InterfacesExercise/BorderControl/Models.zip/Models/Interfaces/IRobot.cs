﻿namespace BorderControl.Models.Interfaces
{
    public interface IRobot : IIdentifiable
    {
        string Model { get; }
    }
}
