﻿namespace _07.Tuple
{
    public class Item1<T>
    {
        public T Value { get; set; }
    }
}