﻿namespace _07.Tuple
{
    public class Item2<V>
    {
        public V Value { get; set; }
    }
}