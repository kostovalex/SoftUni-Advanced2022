﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.Threeuple
{
    public class Item3<U>
    {
        public U Value { get; set; }
    }
}
