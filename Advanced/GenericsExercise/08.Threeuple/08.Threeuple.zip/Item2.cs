﻿namespace _08.Threeuple
{
    public class Item2<V>
    {
        public V Value { get; set; }
    }
}