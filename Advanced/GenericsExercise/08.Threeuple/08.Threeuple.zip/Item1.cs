﻿namespace _08.Threeuple
{
    public class Item1<T>
    {
        public T Value { get; set; }
    }
}